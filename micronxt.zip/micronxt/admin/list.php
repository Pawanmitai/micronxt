<?php
error_reporting(0);
session_start();
//print_r($_SESSION);
if (!isset($_SESSION['admin']))
{
    header("Location: index.php");
    die();
}
$conn=new mysqli('localhost','root','','micronxt');
 if(isset($_POST['inactive']))
    {
            foreach ($_POST['status'] as $value)
            {
                //echo $value;
             $query="UPDATE register SET status='0' WHERE id='$value'";
              mysqli_query($conn,$query);


            }
           
       
    }
    if(isset($_POST['active']))
    {
     
            foreach ($_POST['status'] as $value)
            {
                //echo $value;
             $query="UPDATE register SET status='1' WHERE id='$value'";
              mysqli_query($conn,$query);


            }
          
    }

?>
<!DOCTYPE html>

    <html lang="en">
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >

        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
        <!-- <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css"> -->
       
    </head>
    <style type="text/css">
        .heading{
            padding-top: 1pc;
            padding-bottom: 1pc;
            background-color: #fff;
            color: #4F5155;
            font-size: 30px;

        }
        .padding{
            padding-top: 1pc;
        }

    </style>
    <body>

        
            <form method="post" >
              <div class="container" id="example">
                
                    <div class="co-md-12 mb-3 heading">
                        <center>All the <br> Regisered Candidate List</center>
                    </div>
                    <div class="co-md-12 mb-3 heading text-right">
                        <a href="logout.php">Logout</a>
                    </div>
                    <div class="table-responsive">
                      <table class='table  table-bordered'>
                          <tr style="background-color: #dcdcdc">
                              <td>FIRST NAME</td>
                              <td>LAST NAME</td>
                              <td>EMAIL</td>
                              <td>MOBILE</td>
                              <td>STATUS</td>
                              <td><input type="checkbox" id="checkall" class="chk" name="">
                                <button type="submit" name="active">Active</button>
                                <button type="submit" name="inactive">Inactive</button>
                              </td>
                          </tr>
                      <?php
                        $sql="SELECT * FROM register ORDER BY ID DESC ";
                            $fetch=mysqli_query($conn,$sql);

                            while($row=mysqli_fetch_array($fetch))
                            {
                      ?>
                          <tr style="background-color: #efefef">
                              <td><?php echo $row['firstname']?></td>
                              <td><?php echo $row['lastname']?></td>
                              <td><?php echo $row['email']?></td>
                              <td><?php echo $row['mobile']?></td>
                              <td><?php if($row['status']=='1'){  echo "Active";} else{ echo "Inactive"; }?></td>
                              <td><input type="checkbox" class="chk" name="status[]" value="<?php echo $row['id'];?>"></td>
                          </tr>
                      <?php }?>
                      </table>
                    </div>
                   
                        
                    
            </div>
            </form>
            
    </body>
     <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
     <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>

    </html>
    <script type="text/javascript">
     $(document).ready( function () {
    $('#example').DataTable();
      });
    </script>
<script>
$(document).ready(function() {
    $('#checkall').click(function () {
        if($(this).is(':checked'))
        {
            $('.chk').prop('checked',true);
        }
        else
        {
            $('.chk').prop('checked',false);
        }
       //  alert('hello');
    });
});
</script>
    

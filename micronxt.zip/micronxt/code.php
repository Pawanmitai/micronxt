<?php
$conn=new mysqli('localhost','root','','micronxt');
if(isset($_POST['update']))
{
	$firstname=mysqli_real_escape_string($conn,$_POST['firstname']);
	$lastname=mysqli_real_escape_string($conn,$_POST['lastname']);
	$id=$_POST['id'];
	 mysqli_query($conn,"update register SET firstname='$firstname',lastname='$lastname' where id='$id' ");
	 echo json_encode(['status'=>'Success']);
}

?>
<?php
session_start();
if (!isset($_SESSION['user']))
{
    header("Location: index.php");
    die();
}
$conn=new mysqli('localhost','root','','micronxt');
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Edit page</title>
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

</head>
<style type="text/css">
    .header{
        height: 200px;
        padding: 5rem;
        font-size: 50px;

    }
     .content{
        height: 600px;
        
    }
     .footer{
        height: 200px;
        
    }
</style>

<body>
   
  <div class="container">
    <div class="alert alert-success hide" id="result">
                       
      </div>
      <div class="row header "><center>Update Record</center></div>
                      <div class="row    text-right " style="font-size: 30px;">
                        <a href="logout.php">Logout</a>
                    </div>
      <center>
                    <?php if(isset($_SESSION['status'])){?>
                    <div class="alert alert-success">
                        <?php echo $_SESSION['status'];
                            unset($_SESSION['status']);
                        ?>
                    </div>
                    <?php }?>
                </center>
       <div class="row content">
           <div class="col-md-2"></div>
           <div class="col-md-8">
              
                   <?php
                        $email=$_SESSION['user'];
                        $query=mysqli_query($conn,"select * from register where email='$email'");
                        while($row=mysqli_fetch_array($query))
                        {
                    ?>
                        <form method="post" id="updateing" enctype="multipart/form-data">
                              <div class="row">
                                <div class="col-md-3 mb-3">
                                  <label for="validationDefault01">Firstname</label>
                                  <input name="firstname" value="<?php echo $row['firstname']?>"  pattern="[a-zA-Z ]{2,30}" type="text" name="useremail" class="form-control" id="firstname" placeholder="Enter Email"  required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                  <label for="validationDefault01">Lastname</label>
                                  <input type="text" value="<?php echo $row['lastname']?>" name="lastname" pattern="[a-zA-Z ]{2,30}" class="form-control" id="lastname" placeholder="First name"  required>
                                </div>
                                <div class="col-md-3 mb-3">
                                  <label for="validationDefault01">Email</label>
                                  <input type="email" value="<?php echo $row['email']?>" class="form-control" id="validationDefault01" placeholder="First name" readonly>
                                </div>
                              
                                 
                                <div class="col-md-3 mb-3">
                                  <input type="hidden" name="id" value="<?php echo $row['id']?>">
                                  <input type="hidden" name="update">
                                  <button class="btn btn-primary" type="submit" id="update" name="update">Update</button>
                                   <!-- <button class="btn btn-warning" type="submit" name="delete">Delete</button> -->
                                 
                                </div>

                              </div>
                             
                              <div class="row padding">
                                
                              </div>
                        </form>
                      <?php
                        }
                    ?>   
               
           </div>
           <div class="col-md-2"></div>
       </div>
        <div class="row footer "></div>
  </div>
    <!-- //form section start -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
</body>

</html>
 <script type="text/javascript">
   $(document).ready(function(){
      $('#updateing').on('submit',function(){
        var test=$('#updateing').serialize();
       
        $.ajax({
          url:'code.php',
          type:'post',
          data:test,
          success:function(result){
            $('#result').html(result.status);
          }
         
       });
      });
       
   });
 </script>
<?php
error_reporting(0);
$conn=mysqli_connect('localhost','root','','micronxt');
session_start();
if(isset($_POST['login']))
{
    
    $data=$_POST;
    $email=mysqli_real_escape_string($conn,$data['email']);
    $password=mysqli_real_escape_string($conn,$data['password']);
    $new_password=md5($password);

$querys=mysqli_query($conn,"SELECT * from register where email='$email' and password='$new_password' and status='1'");
 $result= mysqli_fetch_assoc($querys);
 
   if(count($result)>0)
   {
      $_SESSION['user']=$email;
      header('location:editprofile.php');
   }
   else{
         $_SESSION['status']="Email or password is not matched";
   }
}
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Login Page</title>
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<style type="text/css">
    .header{
        height: 200px;
        padding: 5rem;
        font-size: 50px;

    }
     .content{
        height: 600px;
        
    }
     .footer{
        height: 200px;
        
    }
</style>

<body>
   
  <div class="container">
      <div class="row header "><center>Login Now</center></div>
                      <div class="row    text-right " style="font-size: 30px;">
                        <a href="register.php">Register Now</a>
                    </div>
                    <!-- <div style="font-size: 30px;">
                        <a href="admin/index.php">Admin Login</a>
                    </div> -->
      <center>
                    <?php if(isset($_SESSION['status'])){?>
                    <div class="alert alert-success">
                        <?php echo $_SESSION['status'];
                            unset($_SESSION['status']);
                        ?>
                    </div>
                    <?php }?>
                </center>
       <div class="row content">
           <div class="col-md-3"></div>
           <div class="col-md-6">
              
                    <form method="post" action="">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" name="email" pattern="[A-Z0-9._%+-]+@[A-Z0-9.-]{2,8}+\.[A-Z]{2,4}" class="form-control" placeholder="Enter email" required="">
                            
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" name="password" pattern="[a-zA-Z0-9._%@$! *&]{6,15}" minlength="6" maxlength="15" class="form-control" placeholder="Password" required="">

                          </div>
                         
                          <button type="submit" name="login" class="btn btn-primary">Login</button>
                    </form>
               
           </div>
           <div class="col-md-3"></div>
       </div>
        <div class="row footer "></div>
  </div>
    <!-- //form section start -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</body>

</html>
 
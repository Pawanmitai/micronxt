<?php
session_start();
$conn=mysqli_connect('localhost','root','','micronxt');
if(isset($_POST['register']))
{
  $data=$_POST;
  $data['status']=0;
  unset($data['register']);
  $firstname=mysqli_real_escape_string($conn,$data['firstname']);
  $lastname=mysqli_real_escape_string($conn,$data['lastname']);
  $email=mysqli_real_escape_string($conn,$data['email']);
  $mobile=mysqli_real_escape_string($conn,$data['mobile']);
  $password=mysqli_real_escape_string($conn,$data['password']);
  $status=mysqli_real_escape_string($conn,$data['status']);

  if(mysqli_num_rows(mysqli_query($conn,"select * from register where email='$email' OR mobile='$mobile'"))>0){
     $_SESSION['status']="Email and Mobile Number Already Exits";

    
  }else{
    $new_password=md5($password);
    mysqli_query($conn,"insert into register(firstname,lastname,email,mobile,password,status) values('$firstname','$lastname','$email','$mobile','$new_password','$status')");
    
       $_SESSION['status']="Register Successfully";
     
       
  }
}
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Login Page</title>
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<style type="text/css">
    .header{
        height: 150px;
        padding: 4rem;
        font-size: 50px;

    }
     .content{
        height: 600px;
        
    }
     .footer{
        height: 200px;
        
    }
</style>

<body>
   
  <div class="container">
      <div class="row header "><center>Register Now</center></div>
      <div class="row  text-right " style="font-size:40px;color:#dcdcdc"><a href="index.php">Login Now</a></div>
                  <center>
                    <?php if(isset($_SESSION['status'])){?>
                    <div class="alert alert-success">
                        <?php echo $_SESSION['status'];
                            unset($_SESSION['status']);
                        ?>
                    </div>
                    <?php }?>
                </center>
       <div class="row content">
           <div class="col-md-3"></div>
           <div class="col-md-6">
              
                    <form method="post" action="">
                      <div class="form-group">
                            <label for="exampleInputEmail1">First Name</label>
                            <input type="text" name="firstname" pattern="[a-zA-Z ]{2,30}" class="form-control"  required="">
                            
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Last Name</label>
                            <input type="text" name="lastname" pattern="[a-zA-Z ]{2,30}" class="form-control" required="">
                            
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Mobile Number</label>
                            <input type="text" name="mobile" pattern="[0-9]{10}" class="form-control"  required="">
                            
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" name="email" pattern="[A-Z0-9._%+-]+@[A-Z0-9.-]{2,8}+\.[A-Z]{2,4}" class="form-control" required="">
                            
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" name="password" id="pass" pattern="[a-zA-Z0-9._%@$! *&]{6,15}" minlength="6" maxlength="15" class="form-control" required>

                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Confirm Password</label>
                            <input type="password" id="cpass" pattern="[a-zA-Z0-9._%@$! *&]{6,15}" minlength="6" maxlength="15" class="form-control" required>

                          </div>
                         
                          <button type="submit" name="register" id="register" class="btn btn-primary">Register Now</button>
                    </form>
               
           </div>
           <div class="col-md-3"></div>
       </div>
        <div class="row footer "></div>
  </div>
    <!-- //form section start -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</body>

</html>
 <script type="text/javascript">

   $(document).ready(function(){
       $('#register').on('click',function(){
         var pass=$('#pass').val();
         var cpass=$('#cpass').val();
         if(pass==cpass)
         {
           return true;
         }
         else{

          alert('Password are not Matched');
          return false;
         }
         });
   });
 </script>